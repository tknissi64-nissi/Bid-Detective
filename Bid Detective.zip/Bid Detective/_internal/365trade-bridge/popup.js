// The Bid Detective page owns the user workflow.  The extension only supplies the
// authenticated browser-session adapter after the user confirms a single scan.
