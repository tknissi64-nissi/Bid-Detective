(() => {
  chrome.runtime.sendMessage({type:'bid-detective-365-page-ready'}).catch(() => {});
  const pending = new Map();
  window.addEventListener('message', e => { if (e.source === window && e.data?.type === 'bid-detective-365-result') { const done = pending.get(e.data.id); if (done) { pending.delete(e.data.id); done(e.data); } } });
  chrome.runtime.onMessage.addListener((m, _s, reply) => {
    if (m?.type !== 'bid-detective-365-query') return;
    const id = crypto.randomUUID();
    const timer = setTimeout(() => { pending.delete(id); reply({ok:false,message:'中招联合接口响应超时（60 秒）'}); }, 60000);
    pending.set(id, data => { clearTimeout(timer); reply(data); });
    window.postMessage({type:'bid-detective-365-query',id,payload:m.payload}, location.origin);
    return true;
  });
})();
