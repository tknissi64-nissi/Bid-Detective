(() => {
  // Immediate local-app to extension wake-up channel. The localhost page
  // contains no credentials; it only asks the extension to consume the scan
  // task already recorded by Bid Detective's local API.
  window.addEventListener('message', async event => {
    if (event.source !== window || event.origin !== location.origin || event.data?.type !== 'bid-detective-local-run-365') return;
    try {
      const reply = await chrome.runtime.sendMessage({type:'bid-detective-365-run-now'});
      window.postMessage({type:'bid-detective-local-365-ack',ok:Boolean(reply?.ok),message:reply?.message||''},location.origin);
    } catch (error) {
      window.postMessage({type:'bid-detective-local-365-ack',ok:false,message:String(error?.message||error)},location.origin);
    }
  });
  window.postMessage({type:'bid-detective-local-365-ack',ok:true,message:'同步桥已连接'},location.origin);
})();
