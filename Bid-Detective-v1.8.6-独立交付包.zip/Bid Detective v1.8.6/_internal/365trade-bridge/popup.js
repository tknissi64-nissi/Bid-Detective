document.querySelector('#run').addEventListener('click', async () => {
  const status = document.querySelector('#status');
  status.textContent = '正在检查本机待扫描任务…';
  try {
    const reply = await chrome.runtime.sendMessage({type:'bid-detective-365-run-now'});
    status.textContent = reply?.ok ? '已触发，请返回 Bid Detective 查看进度。' : `触发失败：${reply?.message || '未知错误'}`;
  } catch (error) {
    status.textContent = `扩展连接失败：${error.message}`;
  }
});
