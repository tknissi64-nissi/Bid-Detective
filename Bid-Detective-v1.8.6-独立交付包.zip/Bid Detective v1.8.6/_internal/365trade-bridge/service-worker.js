const PAGE = 'https://jy.365trade.com.cn/wb_bidder/static/dist/seekProject';
const LOCAL = 'http://127.0.0.1:8787';
// The site's search component is fixed at 10 rows per page.  Sending 40 does
// not make the API return 40, but using 40 to calculate page count previously
// stopped a 198-row result after page 5 instead of reading all 20 pages.
const PAGE_SIZE = 10;
// The site does not send its visible publish-time selector to the search API.
// Keep paging until Bid Detective's requested cutoff or the true result end.
const MAX_PAGES_PER_KEYWORD = 5000;
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
let scanRunning = false;

class ScanCancelled extends Error {}

async function controlPoint() {
  while (true) {
    const control = await local('/api/bridge/365trade/status');
    if (control.scan_cancelled) throw new ScanCancelled('用户取消任务');
    if (!control.scan_paused) return;
    await sleep(500);
  }
}

async function local(path, init) {
  const response = await fetch(LOCAL + path, init);
  const body = await response.json().catch(() => null);
  if (!response.ok || !body) throw new Error(`Bid Detective 本机接口异常（HTTP ${response.status}）`);
  return body;
}

async function report(ok, message, finished = false, stats = {}) {
  await local('/api/bridge/365trade/report', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ok, message, finished, ...stats})
  });
}

async function loggedSearchTab() {
  // Querying all tabs and filtering in code is more reliable than Chrome's URL
  // match-pattern handling for an SPA route.
  const tabs = (await chrome.tabs.query({})).filter(tab => String(tab.url || '').startsWith(PAGE));
  if (!tabs.length) {
    throw new Error('未找到已登录的“寻找招标项目”标签页；请从 Bid Detective 打开并登录后重试');
  }
  return tabs.sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0];
}

async function query(tabId, payload) {
  let lastMessage = '';
  for (let attempt = 1; attempt <= 15; attempt++) {
    await controlPoint();
    try {
      const reply = await chrome.tabs.sendMessage(tabId, {type: 'bid-detective-365-query', payload});
      if (reply && typeof reply.ok === 'boolean') return reply;
      lastMessage = '页面桥接未返回结构化结果';
    } catch (error) {
      lastMessage = String(error?.message || error || '页面桥接尚未就绪');
    }
    await sleep(500);
    await controlPoint();
    await sleep(500);
  }
  throw new Error(`中招联合搜索页面未就绪：${lastMessage}`);
}

function recordKey(row) {
  return String(row?.projectId || row?.businessCode || row?.projectName || '').trim();
}

function minimalKeywords(words) {
  const ordered = [...new Set(words.map(x => String(x).trim()).filter(Boolean))]
    .sort((a, b) => a.length - b.length || a.localeCompare(b, 'zh-CN'));
  const kept = [];
  for (const word of ordered) {
    const folded = word.toLocaleLowerCase('zh-CN');
    if (!kept.some(shorter => folded.includes(shorter.toLocaleLowerCase('zh-CN')))) kept.push(word);
  }
  return kept;
}

function rowTimestamp(row) {
  const raw = row?.publishTime || row?.publishDate || row?.createTime || row?.startTime || row?.start_at || '';
  if (typeof raw === 'number') return raw > 1e12 ? raw : raw * 1000;
  const text = String(raw).trim();
  if (/^\d{13}$/.test(text)) return Number(text);
  if (/^\d{10}$/.test(text)) return Number(text) * 1000;
  const normalized = text.replace(/[年/.]/g, '-').replace(/月/g, '-').replace(/日/g, '').replace(/-(\d)(?=-|\s|$)/g, '-0$1');
  const parsed = Date.parse(normalized);
  return Number.isFinite(parsed) ? parsed : NaN;
}

async function scanOnce() {
  if (scanRunning) return {ok: true, message: '中招联合扫描已在运行'};
  scanRunning = true;
  let read = 0, matched = 0, added = 0, pages = 0;
  const unique = new Set();
  const keywordStats = [];
  const coverageWarnings = [];
  try {
    const cfg = await local('/api/settings');
    const configuredWords = String(cfg.keywords || '').split(/[,，;；\n]+/).map(x => x.trim()).filter(Boolean);
    const words = minimalKeywords(configuredWords);
    const days = Math.max(1, Math.min(3650, Math.floor(Number(cfg.days) || 30)));
    const cutoff = Date.now() - days * 86400000;
    const tab = await loggedSearchTab();

    // Do not reload or focus the user's tab. The existing initialized Vue page
    // and authenticated axios client are intentionally reused in the background.
    for (const word of (words.length ? words : [''])) {
      await controlPoint();
      let page = 1;
      let totalPages = 1;
      let sourceTotalPages = 1;
      let keywordRead = 0;
      let reachedCutoff = false;
      let oldestTimestamp = NaN;
      do {
        await controlPoint();
        await report(true, `中招联合正在检索“${word || '全部项目'}”：第 ${page}/${totalPages} 页`);
        const result = await query(tab.id, {
          pageSize: PAGE_SIZE,
          pageNum: page,
          projectName: word,
          projectType: '',
          projectRegion: '',
          industryCategory: '',
          purchaseType: '',
          tenderAgencyName: '',
          projectLowBudget: null,
          projectHighBudget: null,
          tendererName: ''
        });
        if (!result.ok) throw new Error(result.message || '中招联合未返回有效检索结果');

        const data = result.data || {};
        const records = Array.isArray(data.records) ? data.records : [];
        const total = Math.max(0, Number(data.total || 0));
        sourceTotalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
        totalPages = Math.min(MAX_PAGES_PER_KEYWORD, sourceTotalPages);
        if (!records.length) break;

        const fresh = records.filter(row => {
          const key = recordKey(row);
          if (!key || unique.has(key)) return false;
          unique.add(key);
          return true;
        });
        if (fresh.length) {
          const imported = await local('/api/bridge/365trade', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({items: fresh})
          });
          matched += Number(imported.matched || 0);
          added += Number(imported.added || 0);
        }
        read += records.length;
        keywordRead += records.length;
        pages++;
        page++;
        const timestamps = records.map(rowTimestamp).filter(Number.isFinite);
        if (timestamps.length) {
          const pageOldest = Math.min(...timestamps);
          oldestTimestamp = Number.isFinite(oldestTimestamp) ? Math.min(oldestTimestamp, pageOldest) : pageOldest;
        }
        if (timestamps.length === records.length && Math.max(...timestamps) < cutoff) {
          reachedCutoff = true;
          break;
        }
      } while (page <= totalPages);
      if (!reachedCutoff && sourceTotalPages > MAX_PAGES_PER_KEYWORD) {
        coverageWarnings.push(`“${word || '全部项目'}”网站共 ${sourceTotalPages} 页，达到安全上限 ${MAX_PAGES_PER_KEYWORD} 页后停止`);
      }
      const oldest = Number.isFinite(oldestTimestamp) ? new Date(oldestTimestamp).toLocaleDateString() : '日期未知';
      keywordStats.push(`${word || '全部项目'} ${keywordRead} 条（最老 ${oldest}，网站 ${sourceTotalPages} 页）`);
    }

    const warning = coverageWarnings.length ? `；覆盖警告：${coverageWarnings.join('；')}` : '';
    const message = `中招联合单次扫描完成：${pages} 页 / ${read} 条网站结果 / ${unique.size} 条去重候选 / ${matched} 条通过本地规则 / 新增 ${added} 条；${keywordStats.join('，')}${warning}`;
    await report(true, message, true, {matched, added, read, pages, unique: unique.size});
    await chrome.storage.local.set({last: message, at: new Date().toLocaleString()});
    return {ok: true, message};
  } catch (error) {
    const cancelled = error instanceof ScanCancelled;
    const message = cancelled
      ? `中招联合扫描已取消：已读取 ${pages} 页 / ${read} 条网站结果`
      : `中招联合单次扫描失败（待自动重试）：${String(error?.message || error)}`;
    await report(false, message, cancelled).catch(() => {});
    await chrome.storage.local.set({last: message, at: new Date().toLocaleString()});
    return {ok: false, message};
  } finally {
    scanRunning = false;
  }
}

async function followBidDetective() {
  try {
    const control = await local('/api/bridge/365trade/status');
    if (control.once_pending) return await scanOnce();
    return {ok: true, message: '本机暂无待执行的中招联合任务'};
  } catch (error) {
    return {ok: false, message: String(error?.message || error)};
  }
}

chrome.alarms.create('bid-detective-control', {periodInMinutes: 1});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'bid-detective-control') followBidDetective();
});
chrome.runtime.onStartup.addListener(followBidDetective);
chrome.runtime.onInstalled.addListener(followBidDetective);
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!['bid-detective-365-page-ready', 'bid-detective-365-run-now'].includes(message?.type)) return;
  followBidDetective().catch(() => {});
  sendResponse({ok:true,message:'已触发中招联合任务检查'});
  return false;
});
followBidDetective();
