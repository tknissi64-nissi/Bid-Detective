(() => {
  const post = (id, body) => window.postMessage({type:'bid-detective-365-result',id,...body}, location.origin);
  const searchView = () => {
    const queue = [window.vm];
    const visited = new Set();
    while (queue.length) {
      const view = queue.shift();
      if (!view || visited.has(view)) continue;
      visited.add(view);
      if (typeof view.search === 'function' && Array.isArray(view.resultList) && 'searchCon' in view) return view;
      queue.push(...(view.$children || []));
    }
    return null;
  };
  window.addEventListener('message', async e => {
    if (e.source !== window || e.data?.type !== 'bid-detective-365-query') return;
    const {id,payload} = e.data;
    try {
      // Reuse the site's initialized application and authenticated request
      // client. The identifier stays inside this page and is never returned.
      const view = searchView();
      if (!view) throw new Error('未找到“寻找招标项目”搜索界面，请保持该页面已打开');
      const userId = view.userInfo && view.userInfo.id;
      const endpoint = view.$wwwConfig && view.$wwwConfig.nodeapi_index_search_projectList;
      if (!userId) throw new Error('当前“寻找招标项目”标签页没有有效用户状态，请在该标签页重新登录');
      if (!endpoint || !view.$axios) throw new Error('中招联合搜索组件尚未初始化完成');
      const request = {...payload, userId};
      const response = await view.$axios.post(endpoint, request);
      const body = response && response.data;
      if (!body || Number(body.code) !== 200) throw new Error((body&&body.message)||'中招联合检索接口未正常返回');
      const data = body.data || {};
      const records = Array.isArray(data.records) ? data.records : [];
      post(id,{ok:true,data:{records:JSON.parse(JSON.stringify(records)),total:Number(data.total||0),pageNum:Number(payload.pageNum||1),pageSize:Number(payload.pageSize||40)}});
    } catch (err) { post(id,{ok:false,message:String(err.message||err)}); }
  });
})();
