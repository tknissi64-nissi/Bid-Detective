const PAGE = 'https://jy.365trade.com.cn/wb_bidder/static/dist/seekProject';
const LOCAL = 'http://127.0.0.1:8787';
const PAGE_SIZE = 40;
const MAX_PAGES_PER_KEYWORD = 300;
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
let scanRunning = false;

async function local(path, init) {
  const response = await fetch(LOCAL + path, init);
  const body = await response.json().catch(() => null);
  if (!response.ok || !body) throw new Error(`Bid Detective 本机接口异常（HTTP ${response.status}）`);
  return body;
}

async function report(ok, message, finished = false, stats = {}) {
  await local('/api/bridge/365trade/report', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ok, message, finished, ...stats})
  });
}

async function loggedSearchTab() {
  // Querying all tabs and filtering in code is more reliable than Chrome's URL
  // match-pattern handling for an SPA route.
  const tabs = (await chrome.tabs.query({})).filter(tab => String(tab.url || '').startsWith(PAGE));
  if (!tabs.length) {
    throw new Error('未找到已登录的“寻找招标项目”标签页；请从 Bid Detective 打开并登录后重试');
  }
  return tabs.sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0];
}

async function query(tabId, payload) {
  let lastMessage = '';
  for (let attempt = 1; attempt <= 15; attempt++) {
    try {
      const reply = await chrome.tabs.sendMessage(tabId, {type: 'bid-detective-365-query', payload});
      if (reply && typeof reply.ok === 'boolean') return reply;
      lastMessage = '页面桥接未返回结构化结果';
    } catch (error) {
      lastMessage = String(error?.message || error || '页面桥接尚未就绪');
    }
    await sleep(1000);
  }
  throw new Error(`中招联合搜索页面未就绪：${lastMessage}`);
}

function recordKey(row) {
  return String(row?.projectId || row?.businessCode || row?.projectName || '').trim();
}

async function scanOnce() {
  if (scanRunning) return false;
  scanRunning = true;
  let read = 0, matched = 0, added = 0, pages = 0;
  const unique = new Set();
  const keywordStats = [];
  try {
    const cfg = await local('/api/settings');
    const words = String(cfg.keywords || '').split(/[,，\n]+/).map(x => x.trim()).filter(Boolean);
    const tab = await loggedSearchTab();

    // Do not reload or focus the user's tab. The existing initialized Vue page
    // and authenticated axios client are intentionally reused in the background.
    for (const word of (words.length ? words : [''])) {
      let page = 1;
      let totalPages = 1;
      let keywordRead = 0;
      do {
        await report(true, `中招联合正在检索“${word || '全部项目'}”：第 ${page}/${totalPages} 页`);
        const result = await query(tab.id, {
          pageSize: PAGE_SIZE,
          pageNum: page,
          projectName: word,
          projectType: '',
          projectRegion: '',
          industryCategory: '',
          purchaseType: '',
          tenderAgencyName: '',
          projectLowBudget: null,
          projectHighBudget: null,
          tendererName: ''
        });
        if (!result.ok) throw new Error(result.message || '中招联合未返回有效检索结果');

        const data = result.data || {};
        const records = Array.isArray(data.records) ? data.records : [];
        const total = Math.max(0, Number(data.total || 0));
        totalPages = Math.min(MAX_PAGES_PER_KEYWORD, Math.max(1, Math.ceil(total / PAGE_SIZE)));
        if (!records.length) break;

        const fresh = records.filter(row => {
          const key = recordKey(row);
          if (!key || unique.has(key)) return false;
          unique.add(key);
          return true;
        });
        if (fresh.length) {
          const imported = await local('/api/bridge/365trade', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({items: fresh})
          });
          matched += Number(imported.matched || 0);
          added += Number(imported.added || 0);
        }
        read += records.length;
        keywordRead += records.length;
        pages++;
        page++;
      } while (page <= totalPages);
      keywordStats.push(`${word || '全部项目'} ${keywordRead} 条`);
    }

    const message = `中招联合单次扫描完成：${pages} 页 / ${read} 条网站结果 / ${unique.size} 条去重候选 / ${matched} 条通过本地规则 / 新增 ${added} 条；${keywordStats.join('，')}`;
    await report(true, message, true, {matched, added, read, pages, unique: unique.size});
    await chrome.storage.local.set({last: message, at: new Date().toLocaleString()});
    return true;
  } catch (error) {
    const message = `中招联合单次扫描失败（待自动重试）：${String(error?.message || error)}`;
    await report(false, message, false).catch(() => {});
    await chrome.storage.local.set({last: message, at: new Date().toLocaleString()});
    return false;
  } finally {
    scanRunning = false;
  }
}

async function followBidDetective() {
  try {
    const control = await local('/api/bridge/365trade/status');
    if (control.once_pending) await scanOnce();
  } catch (_) {}
}

chrome.alarms.create('bid-detective-control', {periodInMinutes: 1});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'bid-detective-control') followBidDetective();
});
chrome.runtime.onStartup.addListener(followBidDetective);
chrome.runtime.onInstalled.addListener(followBidDetective);
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!['bid-detective-365-page-ready', 'bid-detective-365-run-now'].includes(message?.type)) return;
  followBidDetective().catch(() => {});
  sendResponse({ok: true});
  return false;
});
followBidDetective();
