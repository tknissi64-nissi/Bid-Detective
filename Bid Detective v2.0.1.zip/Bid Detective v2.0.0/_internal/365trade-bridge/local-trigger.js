(() => {
  // Immediate local-app to extension wake-up channel. The localhost page
  // contains no credentials; it only asks the extension to consume the scan
  // task already recorded by Bid Detective's local API.
  window.addEventListener('message', async event => {
    if (event.source !== window || event.origin !== location.origin || !['bid-detective-local-run-365','bid-detective-local-run-riskbird'].includes(event.data?.type)) return;
    const riskbird = event.data.type.endsWith('riskbird');
    try {
      const reply = await chrome.runtime.sendMessage({type:riskbird?'bid-detective-riskbird-run-now':'bid-detective-365-run-now'});
      window.postMessage({type:riskbird?'bid-detective-local-riskbird-ack':'bid-detective-local-365-ack',ok:Boolean(reply?.ok),message:reply?.message||''},location.origin);
    } catch (error) {
      window.postMessage({type:riskbird?'bid-detective-local-riskbird-ack':'bid-detective-local-365-ack',ok:false,message:String(error?.message||error)},location.origin);
    }
  });
  window.postMessage({type:'bid-detective-local-365-ack',ok:true,message:'同步桥已连接'},location.origin);
  window.postMessage({type:'bid-detective-local-riskbird-ack',ok:true,message:'同步桥已连接'},location.origin);
})();
