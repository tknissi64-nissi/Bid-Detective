document.querySelector('#run').addEventListener('click', async () => {
  const status = document.querySelector('#status');
  status.textContent = '正在检查本机待扫描任务…';
  try {
    const replies = await Promise.all([
      chrome.runtime.sendMessage({type:'bid-detective-365-run-now'}),
      chrome.runtime.sendMessage({type:'bid-detective-riskbird-run-now'}),
    ]);
    status.textContent = replies.some(reply => reply?.ok) ? '已触发，请返回 Bid Detective 查看进度。' : '触发失败：请检查本机服务与登录页面';
  } catch (error) {
    status.textContent = `扩展连接失败：${error.message}`;
  }
});
