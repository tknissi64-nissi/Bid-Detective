(() => {
  chrome.runtime.sendMessage({type: 'bid-detective-riskbird-page-ready'}).catch(() => {});
  const pending = new Map();
  window.addEventListener('message', event => {
    if (event.source !== window || event.data?.type !== 'bid-detective-riskbird-result') return;
    const done = pending.get(event.data.id);
    if (!done) return;
    pending.delete(event.data.id);
    done(event.data);
  });
  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message?.type !== 'bid-detective-riskbird-query') return;
    const id = crypto.randomUUID();
    const timer = setTimeout(() => {
      pending.delete(id);
      reply({ok: false, message: 'RiskBird接口响应超时（60秒）'});
    }, 60000);
    pending.set(id, data => {
      clearTimeout(timer);
      reply(data);
    });
    window.postMessage({
      type: 'bid-detective-riskbird-query', id, payload: message.payload,
    }, location.origin);
    return true;
  });
})();
