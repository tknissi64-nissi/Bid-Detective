(() => {
  const post = (id, body) => window.postMessage({
    type: 'bid-detective-riskbird-result', id, ...body,
  }, location.origin);

  async function jsonRequest(path, init = {}) {
    const response = await fetch(path, {
      credentials: 'include',
      ...init,
      headers: {'app-device': 'WEB', ...(init.headers || {})},
    });
    const body = await response.json().catch(() => null);
    if (!response.ok || !body) throw new Error(`RiskBird接口异常（HTTP ${response.status}）`);
    return body;
  }

  function unwrap(body) {
    if (body?.state && body.state !== 'success') throw new Error(body.msg || body.message || body.state);
    if (body?.success === false || (body?.code != null && ![200, 20000].includes(Number(body.code)))) {
      throw new Error(body?.msg || body?.message || `RiskBird返回代码 ${body?.code}`);
    }
    const data = body?.data ?? body;
    if (data?.state && data.state !== 'success') throw new Error(data.msg || data.message || data.state);
    return data;
  }

  function parseNestedJson(value) {
    let parsed = value;
    for (let attempt = 0; attempt < 2 && typeof parsed === 'string'; attempt++) {
      try { parsed = JSON.parse(parsed); } catch (_) { break; }
    }
    return parsed;
  }

  function normalizedName(value) {
    return String(value || '').replace(/[()]/g, ch => ch === '(' ? '（' : '）').replace(/\s+/g, '').trim();
  }

  window.addEventListener('message', async event => {
    if (event.source !== window || event.data?.type !== 'bid-detective-riskbird-query') return;
    const {id, payload = {}} = event.data;
    try {
      if (payload.action === 'resolve-bank') {
        const query = new URLSearchParams({entName: String(payload.bank || '')});
        if (payload.entId) query.set('entId', String(payload.entId));
        const body = await jsonRequest(`/api/ent/query?${query}`);
        if (!body.orderNo) throw new Error(body.state === 'unauth' ? 'RiskBird登录已失效' : `未识别企业主体：${payload.bank || ''}`);
        post(id, {ok: true, data: {orderNo: body.orderNo}});
        return;
      }
      if (payload.action === 'find-company') {
        const bank = String(payload.bank || '').trim();
        const query = new URLSearchParams({limit: '5', queryType: '1', key: bank});
        const raw = await jsonRequest(`/riskbird-api/api/v1/companies/fast-search?${query}`);
        const data = unwrap(parseNestedJson(raw));
        const records = Array.isArray(data) ? data : (Array.isArray(data?.data) ? data.data : []);
        const wanted = normalizedName(bank);
        const exact = records.find(row => normalizedName(row?.entName || row?.ENTNAME) === wanted);
        if (!exact?.entid) throw new Error(`未识别企业主体：${bank}`);
        post(id, {ok: true, data: {
          entId: String(exact.entid),
          entName: String(exact.entName || exact.ENTNAME || bank),
        }});
        return;
      }
      if (payload.action === 'list-bids') {
        const request = {
          page: Math.max(1, Number(payload.page || 1)),
          size: Math.max(1, Math.min(100, Number(payload.size || 50))),
          orderNo: String(payload.orderNo || ''),
          filterCnd: 0,
          extractType: 'managementBidNotice',
          sortField: '',
          filterMap: {},
        };
        const body = await jsonRequest('/riskbird-api/api/v1/companies/dimension/list/managementBidNotice', {
          method: 'POST',
          headers: {'Content-Type': 'application/json', 'Xs-Content-Type': 'application/json'},
          body: JSON.stringify(request),
        });
        const data = unwrap(body) || {};
        const records = Array.isArray(data.apiData) ? data.apiData : (Array.isArray(data.list) ? data.list : []);
        post(id, {ok: true, data: {
          records: JSON.parse(JSON.stringify(records)),
          total: Number(data.totalCount || data.count || records.length || 0),
        }});
        return;
      }
      throw new Error('未知RiskBird查询动作');
    } catch (error) {
      post(id, {ok: false, message: String(error?.message || error)});
    }
  });
})();
