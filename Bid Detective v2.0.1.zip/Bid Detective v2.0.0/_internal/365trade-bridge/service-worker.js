const PAGE = 'https://jy.365trade.com.cn/wb_bidder/static/dist/seekProject';
const RISKBIRD_PAGE = 'https://www.riskbird.com/';
const LOCAL = 'http://127.0.0.1:8789';
// The site's search component is fixed at 10 rows per page.  Sending 40 does
// not make the API return 40, but using 40 to calculate page count previously
// stopped a 198-row result after page 5 instead of reading all 20 pages.
const PAGE_SIZE = 10;
// The site does not send its visible publish-time selector to the search API.
// Keep paging until Bid Detective's requested cutoff or the true result end.
const MAX_PAGES_PER_KEYWORD = 5000;
// RiskBird's user agreement forbids non-human continuous/frequent queries.
// Keep each user-triggered run deliberately small and slow.  This is a
// compliance guardrail, not an attempt to bypass account or site limits.
const RISKBIRD_BLOCK_SIZE = 10;
const RISKBIRD_MIN_REQUEST_GAP_MS = 15000;
const RISKBIRD_RATE_LIMIT_COOLDOWN_MS = 30 * 60 * 1000;
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
let scanRunning = false;
let riskbirdRunning = false;

class ScanCancelled extends Error {}

async function controlPoint() {
  while (true) {
    const control = await local('/api/bridge/365trade/status');
    if (control.scan_cancelled) throw new ScanCancelled('用户取消任务');
    if (!control.scan_paused) return;
    await sleep(500);
  }
}

async function riskbirdControlPoint() {
  while (true) {
    const control = await local('/api/bridge/riskbird/status');
    if (control.scan_cancelled) throw new ScanCancelled('用户取消任务');
    if (!control.scan_paused) return;
    await sleep(500);
  }
}

async function riskbirdControlledSleep(milliseconds) {
  const deadline = Date.now() + Math.max(0, milliseconds);
  while (Date.now() < deadline) {
    await riskbirdControlPoint();
    await sleep(Math.min(1000, deadline - Date.now()));
  }
}

async function local(path, init) {
  const response = await fetch(LOCAL + path, init);
  const body = await response.json().catch(() => null);
  if (!response.ok || !body) throw new Error(`Bid Detective 本机接口异常（HTTP ${response.status}）`);
  return body;
}

async function report(ok, message, finished = false, stats = {}) {
  await local('/api/bridge/365trade/report', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ok, message, finished, ...stats})
  });
}

async function loggedSearchTab() {
  // Querying all tabs and filtering in code is more reliable than Chrome's URL
  // match-pattern handling for an SPA route.
  const tabs = (await chrome.tabs.query({})).filter(tab => String(tab.url || '').startsWith(PAGE));
  if (!tabs.length) {
    throw new Error('未找到已登录的“寻找招标项目”标签页；请从 Bid Detective 打开并登录后重试');
  }
  return tabs.sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0];
}

async function loggedRiskbirdTab() {
  const tabs = (await chrome.tabs.query({})).filter(tab => {
    const url = String(tab.url || '');
    return url.startsWith('https://www.riskbird.com/') || url.startsWith('https://riskbird.com/');
  });
  if (!tabs.length) throw new Error('未找到已登录RiskBird标签页；请从Bid Detective打开并登录后重试');
  return tabs.sort((a, b) => Number(b.lastAccessed || 0) - Number(a.lastAccessed || 0))[0];
}

async function query(tabId, payload) {
  let lastMessage = '';
  for (let attempt = 1; attempt <= 15; attempt++) {
    await controlPoint();
    try {
      const reply = await chrome.tabs.sendMessage(tabId, {type: 'bid-detective-365-query', payload});
      if (reply && typeof reply.ok === 'boolean') return reply;
      lastMessage = '页面桥接未返回结构化结果';
    } catch (error) {
      lastMessage = String(error?.message || error || '页面桥接尚未就绪');
    }
    await sleep(500);
    await controlPoint();
    await sleep(500);
  }
  throw new Error(`中招联合搜索页面未就绪：${lastMessage}`);
}

async function riskbirdQuery(tabId, payload) {
  let lastMessage = '';
  for (let attempt = 1; attempt <= 12; attempt++) {
    await riskbirdControlPoint();
    try {
      const timing = await chrome.storage.local.get(['riskbirdLastRequestAt']);
      const elapsed = Date.now() - Number(timing.riskbirdLastRequestAt || 0);
      const jitter = Math.floor(Math.random() * 2500);
      const wait = Math.max(0, RISKBIRD_MIN_REQUEST_GAP_MS - elapsed) + jitter;
      if (wait) await sleep(wait);
      await riskbirdControlPoint();
      await chrome.storage.local.set({riskbirdLastRequestAt: Date.now()});
      const reply = await chrome.tabs.sendMessage(tabId, {type: 'bid-detective-riskbird-query', payload});
      if (reply && typeof reply.ok === 'boolean') return reply;
      lastMessage = '页面桥接未返回结构化结果';
    } catch (error) {
      lastMessage = String(error?.message || error || '页面桥接尚未就绪');
    }
    await sleep(750);
  }
  throw new Error(`RiskBird页面未就绪：${lastMessage}`);
}

function riskbirdLimited(message) {
  return /操作过于频繁|查询频繁|请求频繁|稍后再试|今日.*上限|次数.*上限|too\s*fast|rate\s*limit|\b429\b/i.test(String(message || ''));
}

async function resolveRiskbirdOrderNo(tabId, enterprise) {
  const direct = await riskbirdQuery(tabId, {action: 'resolve-bank', bank: enterprise});
  if (direct.ok && direct.data?.orderNo) return direct;
  if (riskbirdLimited(direct.message)) return direct;

  // Securities and insurers often need RiskBird's canonical entity id before
  // the detail query can create an order number.  Keep each step in a separate
  // riskbirdQuery call so the global 15-second request gap remains effective.
  const found = await riskbirdQuery(tabId, {action: 'find-company', bank: enterprise});
  if (!found.ok || !found.data?.entId) return found.ok
    ? {ok: false, message: `未识别企业主体：${enterprise}`}
    : found;
  return await riskbirdQuery(tabId, {
    action: 'resolve-bank',
    bank: found.data.entName || enterprise,
    entId: found.data.entId,
  });
}

function recordKey(row) {
  return String(row?.projectId || row?.businessCode || row?.projectName || '').trim();
}

function minimalKeywords(words) {
  const ordered = [...new Set(words.map(x => String(x).trim()).filter(Boolean))]
    .sort((a, b) => a.length - b.length || a.localeCompare(b, 'zh-CN'));
  const kept = [];
  for (const word of ordered) {
    const folded = word.toLocaleLowerCase('zh-CN');
    if (!kept.some(shorter => folded.includes(shorter.toLocaleLowerCase('zh-CN')))) kept.push(word);
  }
  return kept;
}

function rowTimestamp(row) {
  const raw = row?.gdate || row?.publishTime || row?.publishDate || row?.createTime || row?.startTime || row?.start_at || '';
  if (typeof raw === 'number') return raw > 1e12 ? raw : raw * 1000;
  const text = String(raw).trim();
  if (/^\d{13}$/.test(text)) return Number(text);
  if (/^\d{10}$/.test(text)) return Number(text) * 1000;
  const normalized = text.replace(/[年/.]/g, '-').replace(/月/g, '-').replace(/日/g, '').replace(/-(\d)(?=-|\s|$)/g, '-0$1');
  const parsed = Date.parse(normalized);
  return Number.isFinite(parsed) ? parsed : NaN;
}

async function scanOnce() {
  if (scanRunning) return {ok: true, message: '中招联合扫描已在运行'};
  scanRunning = true;
  let read = 0, matched = 0, added = 0, pages = 0;
  const unique = new Set();
  const keywordStats = [];
  const coverageWarnings = [];
  try {
    const cfg = await local('/api/settings');
    const configuredWords = String(cfg.keywords || '').split(/[,，;；\n]+/).map(x => x.trim()).filter(Boolean);
    const words = minimalKeywords(configuredWords);
    const days = Math.max(1, Math.min(3650, Math.floor(Number(cfg.days) || 30)));
    const cutoff = Date.now() - days * 86400000;
    const tab = await loggedSearchTab();

    // Do not reload or focus the user's tab. The existing initialized Vue page
    // and authenticated axios client are intentionally reused in the background.
    for (const word of (words.length ? words : [''])) {
      await controlPoint();
      let page = 1;
      let totalPages = 1;
      let sourceTotalPages = 1;
      let keywordRead = 0;
      let reachedCutoff = false;
      let oldestTimestamp = NaN;
      do {
        await controlPoint();
        await report(true, `中招联合正在检索“${word || '全部项目'}”：第 ${page}/${totalPages} 页`);
        const result = await query(tab.id, {
          pageSize: PAGE_SIZE,
          pageNum: page,
          projectName: word,
          projectType: '',
          projectRegion: '',
          industryCategory: '',
          purchaseType: '',
          tenderAgencyName: '',
          projectLowBudget: null,
          projectHighBudget: null,
          tendererName: ''
        });
        if (!result.ok) throw new Error(result.message || '中招联合未返回有效检索结果');

        const data = result.data || {};
        const records = Array.isArray(data.records) ? data.records : [];
        const total = Math.max(0, Number(data.total || 0));
        sourceTotalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
        totalPages = Math.min(MAX_PAGES_PER_KEYWORD, sourceTotalPages);
        if (!records.length) break;

        const fresh = records.filter(row => {
          const key = recordKey(row);
          if (!key || unique.has(key)) return false;
          unique.add(key);
          return true;
        });
        if (fresh.length) {
          const imported = await local('/api/bridge/365trade', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({items: fresh})
          });
          matched += Number(imported.matched || 0);
          added += Number(imported.added || 0);
        }
        read += records.length;
        keywordRead += records.length;
        pages++;
        page++;
        const timestamps = records.map(rowTimestamp).filter(Number.isFinite);
        if (timestamps.length) {
          const pageOldest = Math.min(...timestamps);
          oldestTimestamp = Number.isFinite(oldestTimestamp) ? Math.min(oldestTimestamp, pageOldest) : pageOldest;
        }
        if (timestamps.length === records.length && Math.max(...timestamps) < cutoff) {
          reachedCutoff = true;
          break;
        }
      } while (page <= totalPages);
      if (!reachedCutoff && sourceTotalPages > MAX_PAGES_PER_KEYWORD) {
        coverageWarnings.push(`“${word || '全部项目'}”网站共 ${sourceTotalPages} 页，达到安全上限 ${MAX_PAGES_PER_KEYWORD} 页后停止`);
      }
      const oldest = Number.isFinite(oldestTimestamp) ? new Date(oldestTimestamp).toLocaleDateString() : '日期未知';
      keywordStats.push(`${word || '全部项目'} ${keywordRead} 条（最老 ${oldest}，网站 ${sourceTotalPages} 页）`);
    }

    const warning = coverageWarnings.length ? `；覆盖警告：${coverageWarnings.join('；')}` : '';
    const message = `中招联合单次扫描完成：${pages} 页 / ${read} 条网站结果 / ${unique.size} 条去重候选 / ${matched} 条通过本地规则 / 新增 ${added} 条；${keywordStats.join('，')}${warning}`;
    await report(true, message, true, {matched, added, read, pages, unique: unique.size});
    await chrome.storage.local.set({last: message, at: new Date().toLocaleString()});
    return {ok: true, message};
  } catch (error) {
    const cancelled = error instanceof ScanCancelled;
    const message = cancelled
      ? `中招联合扫描已取消：已读取 ${pages} 页 / ${read} 条网站结果`
      : `中招联合单次扫描失败（待自动重试）：${String(error?.message || error)}`;
    await report(false, message, cancelled).catch(() => {});
    await chrome.storage.local.set({last: message, at: new Date().toLocaleString()});
    return {ok: false, message};
  } finally {
    scanRunning = false;
  }
}

async function riskbirdScanOnce() {
  if (riskbirdRunning) return {ok: true, message: 'RiskBird银行扫描已在运行'};
  riskbirdRunning = true;
  let banksDone = 0, pages = 0, read = 0, matched = 0, added = 0, unresolved = 0;
  const unresolvedNames = [];
  let cursor = 0;
  try {
    const cfg = await local('/api/settings');
    const blockBreakMinutes = Math.max(1, Math.min(60, Math.floor(Number(cfg.riskbird_batch_break_minutes) || 5)));
    const blockBreakMs = blockBreakMinutes * 60 * 1000;
    const banks = [...new Set(String(cfg.riskbird_banks || '').split(/[,，;；\n]+/).map(x => x.trim()).filter(Boolean))];
    if (!banks.length) throw new Error('RiskBird银行主体名单为空');
    const days = Math.max(1, Math.min(3650, Math.floor(Number(cfg.days) || 30)));
    const cutoff = Date.now() - days * 86400000;
    const signature = `${days}\n${banks.join('\n')}`;
    const saved = await chrome.storage.local.get([
      'riskbirdOrderNos', 'riskbirdCursor', 'riskbirdCycleSignature',
      'riskbirdCooldownUntil', 'riskbirdRateLimitCount',
    ]);
    const cooldownUntil = Number(saved.riskbirdCooldownUntil || 0);
    if (Date.now() < cooldownUntil) {
      const until = new Date(cooldownUntil).toLocaleString();
      const message = `RiskBird仍在限流冷却期，${until}后再手动扫描；本次未访问网站`;
      await reportRiskbird(false, message, true);
      return {ok: false, message};
    }
    const tab = await loggedRiskbirdTab();
    const orderNos = saved.riskbirdOrderNos && typeof saved.riskbirdOrderNos === 'object'
      ? saved.riskbirdOrderNos : {};
    if (saved.riskbirdCycleSignature === signature) {
      cursor = Math.max(0, Number(saved.riskbirdCursor || 0));
    } else {
      // A changed date range or enterprise pool defines a new scan cycle.
      // Company order numbers are identity caches, not completion markers:
      // retaining them avoids repeated lookups, but the scan itself must
      // restart at the first company so the new scope cannot skip old rows.
      cursor = 0;
    }
    if (cursor >= banks.length) cursor = 0;
    // One user-triggered task covers the complete configured enterprise pool.
    // The 10-company rests and request gap remain the pacing controls; an
    // arbitrary company-count ceiling must not turn one scan into many clicks.
    const batchEnd = banks.length;
    await chrome.storage.local.set({riskbirdCycleSignature: signature, riskbirdCursor: cursor});

    for (let bankIndex = cursor; bankIndex < batchEnd; bankIndex++) {
      const bank = banks[bankIndex];
      await riskbirdControlPoint();
      await reportRiskbird(true, `RiskBird保守扫描：${bank}（${bankIndex + 1}/${banks.length}）`);
      let orderNo = orderNos[bank] || '';
      if (!orderNo) {
        const resolved = await resolveRiskbirdOrderNo(tab.id, bank);
        if (!resolved.ok || !resolved.data?.orderNo) {
          const reason = String(resolved.message || '');
          if (riskbirdLimited(reason)) {
            const count = Math.max(1, Number(saved.riskbirdRateLimitCount || 0) + 1);
            const cooldown = Date.now() + RISKBIRD_RATE_LIMIT_COOLDOWN_MS * Math.min(4, count);
            await chrome.storage.local.set({riskbirdCursor: bankIndex, riskbirdCooldownUntil: cooldown, riskbirdRateLimitCount: count});
            throw new Error(`RATE_LIMIT:${bank}：${reason}`);
          }
          if (/登录|额度|limit|unauth/i.test(reason)) throw new Error(`${bank}：${reason}`);
          unresolved++;
          unresolvedNames.push(bank);
          banksDone++;
          await chrome.storage.local.set({riskbirdCursor: bankIndex + 1});
          continue;
        }
        orderNo = resolved.data.orderNo;
        orderNos[bank] = orderNo;
        await chrome.storage.local.set({riskbirdOrderNos: orderNos});
      }
      let page = 1;
      let totalPages = 1;
      let retriedResolve = false;
      while (page <= totalPages) {
        await riskbirdControlPoint();
        const result = await riskbirdQuery(tab.id, {
          action: 'list-bids', orderNo, page, size: 50,
        });
        if (!result.ok) {
          const reason = String(result.message || '');
          if (riskbirdLimited(reason)) {
            const count = Math.max(1, Number(saved.riskbirdRateLimitCount || 0) + 1);
            const cooldown = Date.now() + RISKBIRD_RATE_LIMIT_COOLDOWN_MS * Math.min(4, count);
            await chrome.storage.local.set({riskbirdCursor: bankIndex, riskbirdCooldownUntil: cooldown, riskbirdRateLimitCount: count});
            throw new Error(`RATE_LIMIT:${bank}：${reason}`);
          }
          if (!retriedResolve) {
            delete orderNos[bank];
            const resolved = await resolveRiskbirdOrderNo(tab.id, bank);
            if (resolved.ok && resolved.data?.orderNo) {
              orderNo = resolved.data.orderNo;
              orderNos[bank] = orderNo;
              retriedResolve = true;
              await chrome.storage.local.set({riskbirdOrderNos: orderNos});
              continue;
            }
          }
          throw new Error(`${bank}：${result.message || '招投标列表读取失败'}`);
        }
        const records = Array.isArray(result.data?.records) ? result.data.records : [];
        const total = Math.max(0, Number(result.data?.total || records.length));
        totalPages = Math.max(1, Math.ceil(total / 50));
        if (!records.length) break;
        const imported = await local('/api/bridge/riskbird', {
          method: 'POST', headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({items: records}),
        });
        pages++;
        read += records.length;
        matched += Number(imported.matched || 0);
        added += Number(imported.added || 0);
        const timestamps = records.map(rowTimestamp).filter(Number.isFinite);
        if (timestamps.length === records.length && Math.max(...timestamps) < cutoff) break;
        page++;
      }
      banksDone++;
      await chrome.storage.local.set({riskbirdCursor: bankIndex + 1});
      if (banksDone % RISKBIRD_BLOCK_SIZE === 0 && bankIndex + 1 < batchEnd) {
        await reportRiskbird(true, `RiskBird已完成${bankIndex + 1}/${banks.length}家，等待${blockBreakMinutes}分钟后自动继续下一批`);
        await riskbirdControlledSleep(blockBreakMs);
      }
    }
    await chrome.storage.local.set({
      riskbirdCursor: 0,
      riskbirdCooldownUntil: 0,
      riskbirdRateLimitCount: 0,
    });
    const unresolvedHint = unresolvedNames.length
      ? `（如：${unresolvedNames.slice(0, 8).join('、')}${unresolvedNames.length > 8 ? '等' : ''}）`
      : '';
    const message = `RiskBird完整扫描完成：已覆盖${banksDone}/${banks.length}家，${pages}页/${read}条公告，${matched}条通过规则，新增${added}条，${unresolved}家未识别${unresolvedHint}；下次从第1家开始`;
    await reportRiskbird(true, message, true, {matched, added, read, pages, banks: banksDone});
    return {ok: true, message};
  } catch (error) {
    const cancelled = error instanceof ScanCancelled;
    const raw = String(error?.message || error);
    const limited = raw.startsWith('RATE_LIMIT:');
    const message = cancelled
      ? `RiskBird银行扫描已取消：已完成${banksDone}家/${pages}页`
      : limited
        ? `RiskBird触发网站频率限制，已立即停止且不会自动重试；30分钟后手动扫描将从断点继续。${raw.slice('RATE_LIMIT:'.length)}`
        : `RiskBird扫描已停止且不会自动重试：${raw}`;
    // Always finish the one-shot task on error.  Retrying every minute caused
    // repeated rate-limit hits and could endanger the user's account.
    await reportRiskbird(false, message, true, {matched, added, read, pages, banks: banksDone}).catch(() => {});
    return {ok: false, message};
  } finally {
    riskbirdRunning = false;
  }
}

async function reportRiskbird(ok, message, finished = false, stats = {}) {
  await local('/api/bridge/riskbird/report', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      ok, message, finished,
      bridge_version: chrome.runtime.getManifest().version,
      ...stats,
    }),
  });
}

async function follow365trade() {
  try {
    const control = await local('/api/bridge/365trade/status');
    if (control.once_pending) return await scanOnce();
    return {ok: true, message: '本机暂无待执行的中招联合任务'};
  } catch (error) {
    return {ok: false, message: String(error?.message || error)};
  }
}

async function followRiskbird() {
  try {
    const control = await local('/api/bridge/riskbird/status');
    if (control.once_pending) return await riskbirdScanOnce();
    return {ok: true, message: '本机暂无待执行的RiskBird任务'};
  } catch (error) {
    return {ok: false, message: String(error?.message || error)};
  }
}

async function followBidDetective() {
  const results = await Promise.allSettled([follow365trade(), followRiskbird()]);
  return {ok: results.some(item => item.status === 'fulfilled')};
}

chrome.alarms.create('bid-detective-control', {periodInMinutes: 1});
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'bid-detective-control') {
    followBidDetective().catch(() => {});
  }
});
chrome.runtime.onStartup.addListener(() => followBidDetective().catch(() => {}));
chrome.runtime.onInstalled.addListener(() => followBidDetective().catch(() => {}));
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (![
    'bid-detective-365-page-ready', 'bid-detective-365-run-now',
    'bid-detective-riskbird-page-ready', 'bid-detective-riskbird-run-now',
  ].includes(message?.type)) return;
  followBidDetective().catch(() => {});
  sendResponse({ok:true,message:'已触发中招联合任务检查'});
  return false;
});
followBidDetective();
